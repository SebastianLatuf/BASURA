CREATE DATABASE escuela;
use escuela;
CREATE TABLE Faltas (id_falta INT, id_alumno INT, fecha DATE, cantidad INT);
CREATE TABLE Alumno (id_alumno INT, dni INT, nombre VARCHAR(50), direccion VARCHAR(50), telefono INT, curso VARCHAR(50), fecha_de_nacimiento DATE);
CREATE TABLE Notas (id_nota INT, id_alumno INT, id_materia INT, 1_trim INT, 2_trim INT, 3_trim INT, diciembre INT, marzo INT);
CREATE TABLE Materias (id_materia INT, nombre VARCHAR(50), cant_horas INT, curso INT, aula INT);
/* PUNTO 1*/
DELETE FROM Alumno where id_alumno = 42845014;
/* PUNTO 2*/
UPDATE Alumno SET 1_trim = 8 where id_alumno = 25 and id_materia = 8;
/* PUNTO 3*/
SELECT nombre, cant_horas, aula from Materias where curso ="3C" ORDER BY nombre;
/* PUNTO 4*/
DELETE Nombre FROM Materias where curso = "6C";
/* PUNTO 5*/
UPDATE Materias SET curso = "5C" where curso = "4C";
/* PUNTO 6*/
SELECT dni, nombre, fecha_de_nacimiento FROM Materias order by fecha_de_nacimiento DESC;
/* PUNTO 7*/
DROP TABLE Notas;
/* PUNTO 8*/
SELECT MAX(1_trim) FROM Notas where id_materia = 2;
/* PUNTO 9*/
SELECT AVG(diciembre) FROM Notas where id_materia = 3;
/* PUNTO 10*/
INSERT INTO Alumno (dni, nombre, direccion, telefono, curso, fecha_de_nacimiento) Values (45930627, "Lucas", "Calle falsa 123", 1122742895, "3C", 1984-02-20);
