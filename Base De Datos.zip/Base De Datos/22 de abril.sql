Create Database Veterinaria;
use Veterinaria;
Select * from Mascotas group by edad;
Select * from Mascotas group by peso;
Select Count (id_mascota) from Mascotas group by edad;
Select Count (id_mascota) from Mascotas group by peso;
Select Sum (peso) from Mascotas where edad between 5 and 10;
Select Avg (peso) from Mascotas;
DELIMITER //
Create procedure obtenerCantidadDeMascotas(IN id_dueño_i INT)
Begin
Select Count (id_mascota) from Dueños where id_dueño_i;
End //
DELIMITER ;
