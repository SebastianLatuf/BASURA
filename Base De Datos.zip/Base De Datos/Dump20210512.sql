drop database personas;
create database personas;
use personas;
create table alumnos (edad int, nombre varchar(50));
insert into alumnos (edad, nombre) values (12, "agustin");
insert into alumnos (edad, nombre) values (11, "alan");
select * from alumnos where not edad = 12;
select * from alumnos where nombre like 'a%';
select * from alumnos where nombre like 'ag%';
select * from alumnos where nombre like '%n';
select * from alumnos order by edad;
select * from alumnos order by edad desc;
insert into alumnos (edad, nombre) values (13, "nahuel");
insert into alumnos (edad, nombre) values (14, "tomas");
insert into alumnos (edad, nombre) values (15, "alejo");
insert into alumnos (edad, nombre) values (16, "lucas");
select * from alumnos order by nombre;
select * from alumnos order by nombre desc;
alter table alumnos add dni int;
select * from alumnos;
update alumnos set dni = 45930627;
select * from alumnos;
select * from alumnos 
limit 3;
insert into alumnos (edad, dni) values ( 18, 45930627);
select * from alumnos;
create table mascotas ( 
id int not null auto_increment primary key,
nombre varchar(100) not null,
edad int not null, 
genero varchar(50) not null
);
insert into mascotas (nombre, edad, genero) values ("benjamin", 4, "macho");
insert into mascotas (nombre, edad, genero) values ("lucia", 2, "hembra");
insert into mascotas (nombre, edad, genero) values ("Federico", 5, "macho");
select * from mascotas;
alter table mascotas add precio_de_consultas int;
update mascotas set precio_de_consultas = 100 where nombre = "benjamin";
update mascotas set precio_de_consultas = 110 where nombre = "lucia";
update mascotas set precio_de_consultas = 120 where nombre = "Federico";

