1) create database liberia;

2) create table libros (id int not null auto_increment primary key, 
tematica varchar(50),
autor varchar(50),
stock int, 
precio int, 
fecha_de_lanzamiento int, 
editorial varchar(50)
);
create table ventas (id int not null auto_increment primary key,
cantidad_de_libros_vendidos int, 
fecha_de_venta int
);
insert into libros (tematica, autor, stock, precio, fecha_de_lanzamiento, editorial) values ("Matematica", "Pablo Effeberger", 10, 1500, 02-02-2020, "Kapelusz");
insert into libros (tematica, autor, stock, precio, fecha_de_lanzamiento, editorial) values ("Mis cinco sentidos", "Carolina Micha", 7, 1400, 05-02-2019. "Sudamericana");
insert into libros (tematica, autor, stock, precio, fecha_de_lanzamiento, editorial) values ("El mono relojero", "Constantino Vigil", 12, 800, 05-5-2021, "Atlantida");
insert into libros (tematica, autor, stock, precio, fecha_de_lanzamiento, editorial) values ("Redes Informaricas", "Miguel Dederkremer, 5, 1000, 01-11-2019. "Raduses");
insert into libros (tematica, autor, stock, precio, fecha_de_lanzamiento, editorial) values ("Freddy Mercury, biografia", "Lesley Ann Jones", 5, 2200, 05-06-2018, "Alianza");
Insert into ventas(cantidad_de_libros_vendidos, fecha_de_venta) values (6, 03-05-18);
Insert into ventas(cantidad_de_libros_vendidos, fecha_de_venta) values (4, 24-11-19);
Insert into ventas(cantidad_de_libros_vendidos, fecha_de_venta) values (10, 03-05-21);
Insert into ventas(cantidad_de_libros_vendidos, fecha_de_venta) values (5, 03-05-21);

3) select * from libros where stock > 8;

4) select * from libros where stock <= 5;

5) select * from libros where precio between 1000 and 2000;

6) select * from libros where editorial like 'a%';

7) select * from libros where editorial like 's%';

8) select * from libros
order by fecha_de_lanzamiento;

9) select * from ventas
order by fecha_de_venta desc;

10) select sum stock from libros;

11) select max precio from libros;

12) select min precio from libros;

13) select avg from libros;


